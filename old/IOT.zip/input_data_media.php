<!DOCTYPE HTML>
<html>
<head>
<title>IOT PALALANGON</title>
</head>
 
<body>
<form method="get" action="tambah_data_media.php">
   KELEMBAPAN: <input type="text" name="kelembapan" /></br />
   PH: <input type="text" name="ph" /></br />
   SUHU: <input type="text" name="suhu" /></br />
   
   <input type="submit" value="Submit" />
</form>
</body>
</html>