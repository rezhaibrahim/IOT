<!DOCTYPE HTML>
<html>
<head>
<title>IOT PALALANGON</title>
</head>
 
<body>
<form method="get" action="tambah_data_tikus.php">
   TANGGAL: <input type="date" name="tanggal" /></br />
   JAM: <input type="time" name="jam" /></br />
   
   <input type="submit" value="Submit" />
</form>
</body>
</html>