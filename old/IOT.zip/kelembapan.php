<html>
<head>
  <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
  <meta content="utf-8" http-equiv="encoding">
  <title>Kelembapan Media Ternak</title>
 
  <script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
  <script type="text/javascript" src="bootstrap/js/jquery-2.1.1.min.js"></script>
  <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="datatables/css/datatables.css">
  <link rel="stylesheet" type="text/css" href="bootstrap/css/css_hover.css">
  <link rel="stylesheet" type="text/css" href="bootstrap/css/font_size.css">
 
</head>
<body>

<?php 
include 'koneksi.php';
$db = new database();
?>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">IOT Palalangon</a>
    </div>
    <ul class="nav navbar-nav">
	  <li><a href="index.php">Beranda</a></li>
      <li><a href="tampil_kelembapan.php">Kelembapan</a></li>
	  <li><a href="tampil_suhu.php">Suhu</a></li>
	  <li><a href="tampil_ph.php">pH</a></li>
	  <li><a href="tampil_tikus.php">Hama Tikus</a></li>
    </ul>
  </div>
</nav>
<div class="row">
  <div class="col-sm-2"> </div>
  <div class="col-sm-8"><br><br><br><h2><center>KELEMBAPAN MEDIA TERNAK</center></h2></div>
</div>
<div class="row">
  <div class="col-sm-2"> </div>
  <div class="col-sm-8">
    <hr><br>
  </div>
</div>
<div class="row">
  <div class="col-sm-2"></div>
  <div class="col-sm-8">
    <table class="table table-striped table-bordered display" id="example">
      <thead>
        <tr>
          <th>No.</th>
		  <th>Tanggal (YYYY-MM-DD)</th>
		  <th>Jam (HH-MM-SS)</th>
          <th>Kelembapan (%)</th>
        </tr>
      </thead>
	  <tbody>
	<?php
	$no = 1;
	foreach($db->tampil_media_ternak() as $x){
	?>
	<tr>
		<td><?php echo $no++; ?></td>
		<td><?php echo $x['tanggal']; ?></td>
		<td><?php echo $x['jam']; ?></td>
		<td><?php echo $x['kelembapan']; ?></td>
	</tr>
	<?php 
	}
	?>
      </tbody>
    </table>
  </div>
</div>

<script type="text/javascript" src="datatables/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="datatables/datatables.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable( {      
         "searching": false,
         "paging": true, 
         "info": true,         
         "lengthChange":true 
    } );
} );
</script>

</body>
</html>