<?php 
class database{

	var $host = "localhost";
	var $uname = "root";
	var $pass = "";
	var $db = "iot_palalangon";

	function __construct(){
		mysql_connect($this->host, $this->uname, $this->pass);
		mysql_select_db($this->db);
	}
}

class media_ternak{
	function tampil_media_ternak(){
		$this->db = new database();
		$this->db->__construct();
		$data = mysql_query("select * from media_ternak order by no desc");
		while($d = mysql_fetch_array($data)){
			$hasil[] = $d;
		}
		return $hasil;
	}
	
	function tampil_terakhir(){
		$this->db = new database();
		$this->db->__construct();
		$data = mysql_query("select * from media_ternak order by no desc limit 1");
		while($d = mysql_fetch_array($data)){
			$hasil[] = $d;
		}
		return $hasil;
	}
	
	function input_media_ternak($kelembapan,$ph,$suhu){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("insert into media_ternak (tanggal,jam,kelembapan,ph,suhu)values(CURRENT_DATE,CURRENT_TIME,'$kelembapan','$ph','$suhu')");
	}
}

class hama_tikus{
	function tampil_data_tikus(){
		$this->db = new database();
		$this->db->__construct();
		$data = mysql_query("select * from hama_tikus order by no desc");
		while($d = mysql_fetch_array($data)){
			$hasil[] = $d;
		}
		return $hasil;
	}
	
	function input_tikus(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("insert into hama_tikus (tanggal,jam) values(CURRENT_DATE,CURRENT_TIME)");
	}
}

class alat{
	function aktif_pompa(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 1 WHERE no=1");
	}
	
	function aktif_lampu(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 1 WHERE no=2");
	}
	
	function aktif_kipas(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 1 WHERE no=3");
	}
	
	function aktif_antisipasi(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 1 WHERE no=4");
	}
	
	function mati_pompa(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 0 WHERE no=1");
	}
	
	function mati_lampu(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 0 WHERE no=2");
	}
	
	function mati_kipas(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 0 WHERE no=3");
	}
	
	function mati_antisipasi(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 0 WHERE no=4");
	}
	
	function otomatis_pompa(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 2 WHERE no=1");
	}
	
	function otomatis_lampu(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 2 WHERE no=2");
	}
	
	function otomatis_kipas(){
		$this->db = new database();
		$this->db->__construct();
		mysql_query("UPDATE status_alat SET status = 2 WHERE no=3");
	}
	
	function tampil_pompa(){
		$this->db = new database();
		$this->db->__construct();
		$data = mysql_query("select alat, (CASE WHEN status=0 THEN 'Non-Aktif' WHEN status=1 THEN 'Aktif' ELSE 'Otomatis' END) AS status from status_alat WHERE no=1");
		while($d = mysql_fetch_array($data)){
			$hasil[] = $d;
		}
		return $hasil;
	}
	
	function tampil_lampu(){
		$this->db = new database();
		$this->db->__construct();
		$data = mysql_query("select alat, (CASE WHEN status=0 THEN 'Non-Aktif' WHEN status=1 THEN 'Aktif' ELSE 'Otomatis' END) AS status from status_alat where no=2");
		while($d = mysql_fetch_array($data)){
			$hasil[] = $d;
		}
		return $hasil;
	}
	
	function tampil_kipas(){
		$this->db = new database();
		$this->db->__construct();
		$data = mysql_query("select alat, (CASE WHEN status=0 THEN 'Non-Aktif' WHEN status=1 THEN 'Aktif' ELSE 'Otomatis' END) AS status from status_alat where no=3");
		while($d = mysql_fetch_array($data)){
			$hasil[] = $d;
		}
		return $hasil;
	}
	
	function tampil_antisipasi(){
		$this->db = new database();
		$this->db->__construct();
		$data = mysql_query("select alat, (CASE WHEN status=0 THEN 'Non-Aktif' WHEN status=1 THEN 'Aktif' ELSE 'Otomatis' END) AS status from status_alat where no=4");
		while($d = mysql_fetch_array($data)){
			$hasil[] = $d;
		}
		return $hasil;
	}
	
	function tampil_alat(){
		$this->db = new database();
		$this->db->__construct();
		$data = mysql_query("select * from status_alat");
		while($d = mysql_fetch_array($data)){
			$hasil[] = $d;
		}
		return $hasil;
	}
} 

?>