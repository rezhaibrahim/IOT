<?php
include 'koneksi.php';
$db = new alat();

foreach($db->tampil_alat() as $x){
echo $x['status'];
}
?>