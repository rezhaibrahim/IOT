<?php 
include 'koneksi.php';
$db = new hama_tikus();

$db->input_tikus();

?>