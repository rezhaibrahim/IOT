<?php 
include 'koneksi.php';
$db = new database();

$db->input_media_ternak($_GET['tanggal'],$_GET['jam'],$_GET['kelembapan'],$_GET['ph'],$_GET['suhu']);

?>