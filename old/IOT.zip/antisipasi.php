<?php 

header('Location: /IOT/control.php');

include 'koneksi.php';
$db = new alat();

if (isset($_GET["btn_aktif"])){
	$db->aktif_antisipasi();
} else if (isset($_GET["btn_non"])){
	$db->mati_antisipasi();
}

?>