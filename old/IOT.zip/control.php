<html>
<head>
  <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
  <meta content="utf-8" http-equiv="encoding">
  <title>IOT Palalangon Farm</title>
 
  <script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
  <script type="text/javascript" src="bootstrap/js/jquery-2.1.1.min.js"></script>
  <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="bootstrap/css/font_size.css">
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="datatables/css/datatables.css">
  <link rel="stylesheet" type="text/css" href="bootstrap/css/css_hover.css">
  
 
</head>

<body>
<nav class="navbar navbar-inverse ">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">IOT Palalangon</a>
    </div>
    <ul class="nav navbar-nav">
	  <li><a href="index.php">Beranda</a></li>
      <li><a href="tampil_kelembapan.php">Kelembapan</a></li>
	  <li><a href="tampil_suhu.php">Suhu</a></li>
	  <li><a href="tampil_ph.php">pH</a></li>
	  <li><a href="tampil_tikus.php">Hama Tikus</a></li>
	  <li><a href="control.php">Kontroling</a></li>
    </ul>
  </div>
</nav>

<?php 
include 'koneksi.php';
$db = new alat();
?>

<div class="row">
<br>
<hr>
<div class="col-sm-1"></div>
<div class="col-sm-10 frame1">
	<center>
	<br>
	<font class="ukuran1">Kontroling Media Ternak Cacing Tanah</font>
	<br>
	<br>

	</table>
	
	<table	width=100%>
		<tr>
		<td width=25% colspan=3><div class="hkelembapan"><center>Pompa Air</center></div></td>
		<td>&nbsp</td>
		<td>&nbsp</td>
		<td width=25% colspan=3><div class="hlampu"><center>Lampu Pijar</center></div></td>
		<td>&nbsp</td>
		<td>&nbsp</td>
		<td width=25% colspan=3><div class="hph"><center>Kipas</center></div></td>
		<td>&nbsp</td>
		<td>&nbsp</td>
		<td width=25% colspan=3><div class="hantisipasi"><center>Antisipasi Hama</center></div></td>
		</tr>
		
		<tr>
		<td colspan=3>
		<?php
		foreach($db->tampil_pompa() as $x){
		?>
		<div class="bpompa"><center><?php echo $x['status']; ?></center></div></td>
		<?php
		}
		?>
		<td>&nbsp</td>
		<td>&nbsp</td>
		
		<td colspan=3>
		<?php
		foreach($db->tampil_lampu() as $x){
		?>
		<div class="blampu"><center><?php echo $x['status']; ?></center></div></td>
		<?php
		}
		?>
		<td>&nbsp</td>
		<td>&nbsp</td>
		
		<td colspan=3>
		<?php
		foreach($db->tampil_kipas() as $x){
		?>
		<div class="bkipas"><center><?php echo $x['status']; ?></center></div></td>
		<?php
		}
		?>
		<td>&nbsp</td>
		<td>&nbsp</td>
		
		<td colspan=3>
		<?php
		foreach($db->tampil_antisipasi() as $x){
		?>
		<div class="bantisipasi"><center><?php echo $x['status']; ?></center></div></td>
		<?php
		}
		?>
		
		<tr>
		<td>&nbsp</td>
		<td>&nbsp</td>
		</tr>
		
		<tr>
			<td width=12%>
				<center>
				<form method="get" action="pompa.php">
				<button type="submit" class="btn btn-success btn-block btn-lg" id="btn_non" name="btn_aktif">Aktif</button>
				</form>
				</center>
			</td>
			<td>&nbsp</td>
			<td width=12%>
				<center>
				<form method="get" action="pompa.php">
				<button type="submit" class="btn btn-danger btn-block btn-lg" id="btn_non" name="btn_non">Non-Aktif</button>
				</form>
				</center>
			</td>
			<td>&nbsp</td>
			<td>&nbsp</td>
			<td width=12%>
				<center>
				<form method="get" action="lampu.php">
				<button type="submit" class="btn btn-success btn-block btn-lg" id="btn_non" name="btn_aktif">Aktif</button>
				</form>
				</center>
			</td>
			<td>&nbsp</td>
			<td width=12%>
				<center>
				<form method="get" action="lampu.php">
				<button type="submit" class="btn btn-danger btn-block btn-lg" id="btn_non" name="btn_non">Non-Aktif</button>
				</form>
				</center>
			</td>
			<td>&nbsp</td>
			<td>&nbsp</td>
			
			<td width=12%>
				<center>
				<form method="get" action="kipas.php">
				<button type="submit" class="btn btn-success btn-block btn-lg" id="btn_non" name="btn_aktif">Aktif</button>
				</form>
				</center>
			</td>
			<td>&nbsp</td>
			<td width=12%>
				<center>
				<form method="get" action="kipas.php">
				<button type="submit" class="btn btn-danger btn-block btn-lg" id="btn_non" name="btn_non">Non-Aktif</button>
				</form>
				</center>
			</td>
			<td>&nbsp</td>
			<td>&nbsp</td>
			<td width=12%>
				<center>
				<form method="get" action="antisipasi.php">
				<button type="submit" class="btn btn-success btn-block btn-lg" id="btn_non" name="btn_aktif">Aktif</button>
				</form>
				</center>
			</td>
			<td>&nbsp</td>
			<td width=12%>
				<center>
				<form method="get" action="antisipasi.php">
				<button type="submit" class="btn btn-danger btn-block btn-lg" id="btn_non" name="btn_non">Non-Aktif</button>
				</form>
				</center>
			</td>
		</tr>
		<tr>
			<td colspan=3>
				<center>
				<form method="get" action="pompa.php">
				<button type="submit" class="btn btn-info btn-block btn-lg" id="btn_oto" name="btn_oto">Otomatis</button>
				</form>
				</center>
			</td>
			<td>&nbsp</td>
			<td>&nbsp</td>
			<td colspan=3>
				<center>
				<form method="get" action="lampu.php">
				<button type="submit" class="btn btn-info btn-block btn-lg" id="btn_oto" name="btn_oto">Otomatis</button>
				</form>
				</center>
			</td>
			<td>&nbsp</td>
			<td>&nbsp</td>
			<td colspan=3>
				<center>
				<form method="get" action="kipas.php">
				<button type="submit" class="btn btn-info btn-block btn-lg" id="btn_oto" name="btn_oto">Otomatis</button>
				</form>
				</center>
			</td>
		</tr>
	</table>
	<br>
	</center>
	</div>
</body>
</html>